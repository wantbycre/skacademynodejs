
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path');

var app = express();

// all environments
app.set('port', process.env.PORT || 3001);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);
var request = require('request');
app.post('/comment/add',function(req,res){
	var movieName = urlencode.encode(req.body.title);
	request.post({url:'http://127.0.0.1:3000/movies/comment/'+movieName,
		form:{comment:req.body.comment}}, function(err,httpResponse,body){
			console.log(body);
			res.redirect('/movie/'+movieName);
		});
});
app.post('/movie/add',function(req,res){
	console.log(req.body.title);
	console.log(req.body.director);
	request.post({url:'http://127.0.0.1:3000/movies', 
		form: {title:req.body.title, director:req.body.director,
			year:req.body.year, synopsis:req.body.synopsis}}, 
		function(err,httpResponse,body){  
			console.log(body);
			res.redirect('/');
		});
});
var urlencode = require('urlencode');
app.post('/movie/modify',function(req,res){
	var movieName = urlencode.encode(req.body.title);
	request.put({url:'http://127.0.0.1:3000/movies/'+movieName,
		form:{title:req.body.title, director:req.body.director,
			year:req.body.year, synopsis:req.body.synopsis}},
		function(err,httpResponse,body){
			console.log(body);
			res.redirect('/movie/'+movieName);
		});
});
app.post('/movies/modify',function(req,res){
	 request.put({url:'http://127.0.0.1:3000/movies',
		 form:{movieList:req.body.movies}}, function(err,httpResponse,body){
			console.log(body);
			res.redirect('/');
		 });
});
app.post('/movie/delete',function(req,res){
	var movieName = urlencode.encode(req.body.title);
	request.del({url:'http://127.0.0.1:3000/movies/'+movieName,
		form:{}}, function(err,httpResponse,body){
			console.log(body);
			res.redirect('/');
		});
});
app.post('/movies/delete',function(req,res){
	request.del({url:'http://127.0.0.1:3000/movies', form:{}}, 
			function(err,httpResponse,body){
			console.log(body);
			res.redirect('/');
		});
});
app.get('/movie/:movie',function(req,res){
	var movieName = req.params.movie;
	movieName = urlencode.encode(movieName);
	request('http://127.0.0.1:3000/movies/'+movieName, 
			function (error, response, body) {
		if (!error && response.statusCode == 200) {
			res.render('detail.jade',{title:'Movie Info',
				movie:{title:req.params.movie,
					director:(JSON.parse(body)).director,
					year:(JSON.parse(body)).year,
					synopsis:(JSON.parse(body)).synopsis,
					comments:(JSON.parse(body)).comments}});
		}
	});
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
