
/*
 * GET home page.
 */
var request = require('request');
exports.index = function(req, res){
	request('http://127.0.0.1:3000/movies', function (error, response, body) {
		if (!error && response.statusCode == 200) {
			res.render('index', { title:'Movie List',movies:JSON.parse(body) });
		}
	});
};