/**
 * server.js
 */
var http = require('http');
var fs = require('fs');
var querystring = require('querystring');
var movies = [
	{
		title:'쥬라기월드', director:'콜린 트레보로우'
	},
	{
		title:'스타워즈', director:'조지 루카스'
	},
	{
		title:'인터스텔라', director:'크리스토퍼 놀란'
	}
];
var server = http.createServer(function(req,res){
	if (req.method == 'GET') {
		if (req.url == '/') {
			res.writeHead(200, {'Content-Type':'text/html;charset=UTF8'});
			fs.createReadStream('index.html').pipe(res);
		} else if (req.url == '/list') {
			var html = '<html><body><H1>Favorite Movie</H1><UL>';
			for (var i = 0; i < movies.length; i++) {
				html += '<LI>'+movies[i].title+'('+movies[i].director+')</LI>';
			}
			html += '</UL><H2>새 영화 입력</H2>';
			html += '<FORM METHOD="POST" ACTION="/add/movie">';
			html += '<INPUT TYPE="TEXT" NAME="title">';
			html += '<BR><INPUT TYPE="TEXT" NAME="director">';
			html += '<BR><INPUT TYPE="SUBMIT" VALUE="Upload">';
			html += '</FORM>';
			html += '</body></html>';
			res.writeHead(200, {'Content-Type':'text/html;charset=UTF8'});
			res.end(html);
		}
	} else if (req.method == 'POST') {
		if (req.url == '/add/movie') {
			var body = '';
			req.on('data',function(chunk) { body += chunk; });
			req.on('end', function() {
				movie = querystring.parse(body);//전달받은 쿼리를 객체로 변환
				movies.push(movie);//객체를 배열에 추가
				res.statusCode = 302;//list페이지로 리다이렉트
				res.setHeader('Location','/list');
				res.end();
			});
		} else if (req.url == '/upload') {
			var body = '';
			req.on('data',function(chunk) {
				body += chunk;
			});
			req.on('end',function() {
				var parsed = querystring.parse(body);
				res.end(JSON.stringify(parsed));
			});
		}
	}
});
server.listen(3000);