/**
 * RESTfulAPIExam server.js
 */
var http = require('http');
/*var movieList = ['아바타','스타워즈','인터스텔라'];
var movieDetail = {
	'아바타':{
		director:'제임스 카메론'
	},
	'스타워즈':{
		director:'조지 루카스'
	},
	'인터스텔라':{
		director:'크리스토퍼 놀란'
	}
};*/
/////////////////////////////////////////////////////////////////////////////
var mysql = require('mysql');
var connection = mysql.createConnection({
	host:'localhost', user:'root', password:'1234', database:'moviest'
});
connection.connect(function(err) {
	if (err) { console.err(err); return; }
	console.log('connected as id:'+connection.threadId);
});
var MongoClient = require('mongodb').MongoClient;
var mongodb;
MongoClient.connect('mongodb://localhost:27017/moviest', function(err,db) {
	if (err) { console.err(err); return; }
	console.log('Connected correctly to server');
	mongodb = db;
});
/////////////////////////////////////////////////////////////////////////////
var server = http.createServer(function(req,res){
	var method = req.method.toLowerCase();
	switch(method) {
	case 'get': 	handleGetRequest(req,res); return;
	case 'post': 	handlePostRequest(req,res); return;
	case 'put': 	handlePutRequest(req,res); return;
	case 'delete': 	handleDeleteRequest(req,res); return;
	default: 		res.statusCode = 404; res.end('Wrong method'); return;	
	}
});
server.listen(3000);
var urlencode = require('urlencode');
function handleGetRequest(req,res) {
	if (req.url == '/movies') {//영화 전체 목록 조회 API
		connection.query('select title from movie;', function(err, results) {
			var list = [];
			for (var i = 0; i < results.length; i++) {
				list.push(results[i].title);
			}
			res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
			res.end(JSON.stringify(list));
		});
	} else {//특정 영화 정보 조회 API
		var itemName = req.url.split('/')[2];
		itemName = urlencode.decode(itemName);//URL디코딩
		connection.query('select * from movie where title=?;', [itemName],
				function(err,results) {
			if (err) { res.statusCode = 404; res.end('Wrong movie name'); }
			if (results.length > 0) {
				var movieCollection = mongodb.collection('movie');
				movieCollection.find({movie_id:results[0].movie_id}).toArray(function(err,docs){
					var joinResult = JSON.stringify(results[0]);
					joinResult = JSON.parse(joinResult);
					if (docs.length > 0) {
						joinResult.comments = docs[0].comments;
					} else {
						joinResult.comments = [];
					}
					res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
					res.end(JSON.stringify(joinResult));
				});
			} else {
				res.statusCode = 404; res.end('Wrong movie name');
			}
		});
		/*var item = movieDetail[itemName];//해당 영화정보를 객체로 받아옴
		if (item) {
			res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
			res.end(JSON.stringify(item));
		} else {
			res.statusCode = 404; res.end('Wrong movie name');
		}*/
	}
}
var querystring = require('querystring');
function handlePostRequest(req,res) {
	if (req.url == '/movies') {//새로운 영화 정보 추가 API
		var body = '';
		req.on('data',function(chunk) { body += chunk; });
		req.on('end',function() {
			var movie = querystring.parse(body);
			connection.query(
				'insert into movie(title,director,year,synopsis) values(?,?,?,?);',
				[movie.title, movie.director, Number(movie.year), movie.synopsis],
				function(err, results) {
					if (err) { res.statusCode = 404; res.end('Wrong movie name'); } 
					else {
						res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
						res.end(JSON.stringify(results));
					}
				});
			/*movieList.push(movie.title);
			movieDetail[movie.title] = {director:movie.director};
			res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
			res.end(JSON.stringify({result:true,movieList:movieList,movie:movie}));*/
		});
	} else {//영화 댓글 추가 API (형식:/movies/comment/영화이름)
		var itemName = req.url.split('/')[3];//영화이름추출
		itemName = urlencode.decode(itemName);//URL디코딩
		var body = '';
		req.on('data',function(chunk) { body += chunk; });
		req.on('end',function() {
			var movie = querystring.parse(body);
			connection.query('select movie_id from movie where title=?;',
					[itemName], function(err, results) {
				if (results.length > 0) {//해당 영화에 대한 movie_id가 존재함을 의미
					var movieCollection = mongodb.collection('movie');
					movieCollection.find({movie_id:results[0].movie_id})
									.toArray(function(err, docs) {
						if (docs.length > 0) {//기존에 댓글이 존재함을 의미
							movieCollection.update({movie_id:results[0].movie_id},
									{'$push':{comments:movie.comment}},//기조 도큐먼트 수정
									function(err, result) {
										res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
										res.end(JSON.stringify(result));
									});
						} else {//해당 movie_id에 대한 댓글이 없음을 의미
							movieCollection.save(//새로운 도큐먼트 추가
									{movie_id:results[0].movie_id,comments:[movie.comment]},
									function(err, result) {
										res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
										res.end(JSON.stringify(result));
									});
						}
					});
				}
			});
		});
	}
}
var async = require('async');
function handlePutRequest(req,res) {
	if (req.url == '/movies') {//영화 목록 전체 변경 API
		var body = '';
		req.on('data',function(chunk) { body += chunk; });
		req.on('end',function() {
			var movie = querystring.parse(body);
			var movies = JSON.parse(movie.movieList);//JSON문자열 -> 객체(배열)
			connection.query('delete from movie;',function(err,result){
				if (err) { res.statusCode = 404; res.end('Wrong movie name'); } 
				else {
//[{"title":"이웃집 토토로","director":"미야자키 하야오","year":1988,"synopsis":"1955년 일본의 아름다운 시골 마을. 상냥하고 의젓한 11살 사츠키와 장난꾸러기에 호기심 많은 4살의 메이 는 사이좋은 자매로 아빠와 함께 도시를 떠나 시골로 이사온다. 자상한 아빠 쿠사카베타츠오는 도쿄에서 대학 연구원이며, 입원 중이지만 따뜻한 미소를 잃지 않는 엄마가 있다. 곧 퇴원하실 엄마를 공기가 맑은 곳에서 맞이하기 위해서다. 숲 한복판에 금방이라도 쓰러질 것처럼 낡은 집을 보며 자매는 새로운 환경에 대한 호기심으로 잔뜩 들뜬다."}]
					var funcList = []; var count = 0;
					for (var i = 0; i < movies.length; i++) {
						var func1 = function(callback) {
							connection.query(
					'insert into movie(title,director,year,synopsis) values(?,?,?,?);',
								[movies[count].title,movies[count].director,
								 Number(movies[count].year),movies[count].synopsis],
								 function(err,result){ callback(null,result); });
							count++;
						};
						funcList.push(func1);
					}
					async.series(funcList, function(err,results) {
						res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
						res.end(JSON.stringify(results));
					});
				}
			});
			
			/*movieList = [];//기존 영화 목록 초기화
			movieDetail = {};//기존 영화 상세정보 초기화
			for (var i = 0; i < movies.length; i++) {
				movieList.push(movies[i].title);
				movieDetail[movies[i].title] = {director:movies[i].director};
			}
			res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
			res.end(JSON.stringify({result:true,movieList:movieList,movieDetail:movieDetail}));*/
		});
	} else {//영화 정보 수정 API (만일 해당 영화가 없으면 영화 정보 추가)
		var itemName = req.url.split('/')[2];
		itemName = urlencode.decode(itemName);//URL디코딩
		var body = '';
		req.on('data',function(chunk) { body += chunk; });
		req.on('end',function() {
			var movie = querystring.parse(body);
			connection.query('select * from movie where title=?;',[itemName], function(err,results){
				if (err) { res.statusCode = 404; res.end(err); } 
				else {
					if (results.length > 0) {
						connection.query(
							'update movie set director=?,year=?,synopsis=? where title=?;',
							[movie.director,Number(movie.year),movie.synopsis,itemName],
							function(err,result) {
								if (err) { res.statusCode = 404; res.end(err); } 
								else {
									res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
									res.end(JSON.stringify(result));
								}
							});
					} else {
						connection.query(
							'insert into movie(title,director,year,synopsis) values(?,?,?,?);',
							[itemName, movie.director, Number(movie.year), movie.synopsis],
							function(err,result) {
								if (err) { res.statusCode = 404; res.end(err); } 
								else {
									res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
									res.end(JSON.stringify(result));
								}
							});
					}
				}
			});
			/*if (movieDetail[itemName]) {//기존 영화 정보가 있을 경우
				movieDetail[itemName].director = movie.director;
			} else {//영화정보가 없을 경우
				movieList.push(itemName);
				movieDetail[itemName] = { director : movie.director };
			}
			res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
			res.end(JSON.stringify({result:true,movieDetail:movieDetail}));*/
		});
	}
}
function handleDeleteRequest(req,res) {
	if (req.url == '/movies') {//전체 목록 삭제 API
		connection.query('delete from movie;', function(err,result) {
			if (err) { res.statusCode = 404; res.end(err); } 
			else {
				res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
				res.end(JSON.stringify(result));
			}
		});
		/*movieList = [];movieDetail = {};
		res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
		res.end(JSON.stringify({result:true,movieList:movieList,movieDetail:movieDetail}));*/
	} else {//특정 영화 정보 삭제  API
		var itemName = req.url.split('/')[2];
		itemName = urlencode.decode(itemName);//URL디코딩
		connection.query('delete from movie where title=?;',[itemName],
				function(err,result) {
			if (err) { res.statusCode = 404; res.end(err); } 
			else {
				res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
				res.end(JSON.stringify(result));
			}
		});
		/*if (movieDetail[itemName]) {
			var index = movieList.indexOf(itemName);
			if (index != -1) movieList.splice(index,1);//배열에서 영화 이름 제거
			delete movieDetail[itemName];//영화 상세 정보 제거
			res.writeHead(200, {'Content-Type':'application/json;charset=UTF-8'});
			res.end(JSON.stringify({result:true,movieList:movieList,movieDetail:movieDetail}));
		} else {
			res.statusCode = 404; res.end('Wrong movie name');
		}*/
	}
}